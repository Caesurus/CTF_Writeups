cat ./logo && timeout 120 ./ezROP
